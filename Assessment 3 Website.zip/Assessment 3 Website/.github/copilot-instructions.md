# Bart Simpson Portfolio Template - AI Assistant Instructions

This document guides AI agents on working with this Bootstrap 5-based portfolio template.

## Project Overview

A multi-page responsive portfolio website template built with Bootstrap 5, featuring:

- Landing page with typewriter animation
- Resume page with interactive sections
- Projects gallery with lightbox functionality 
- Contact page with form and map integration
- Custom dark/light mode switching

## Key Files & Structure

```
├── index.html         # Landing page with typewriter effect
├── resume.html        # Resume with progress bars and cards
├── projects.html      # Portfolio gallery with lightbox
├── contact.html       # Contact form and map
├── css/
│   └── custom.css     # Custom styles overriding Bootstrap
├── js/
│   ├── switch.js      # Dark/light mode functionality
│   ├── script.js      # Main JS functionality
│   └── cursor.js      # Cursor animation effects
└── img/              # Image assets
```

## Core Components & Patterns

### 1. Navigation

- Sticky navbar with responsive toggle
- Consistent structure across all pages
- Active state handling for current page

### 2. Bootstrap Customization

- Custom colors defined in `custom.css`
- Responsive breakpoints: 575.98px, 767.98px, 991.98px, 1199.98px
- Google Fonts: Oswald (headings) and Montserrat (body)

### 3. Key Features

**Lightbox Gallery**:
- Modal-based image/video display in `projects.html`
- Supports both images and YouTube videos
- Navigation between items with prev/next buttons

**Dark/Light Mode**:
- Implemented in `switch.js`
- Uses localStorage for persistence
- Auto-detects system preference

**Typewriter Effect**:
- Landing page animation in `index.html`
- Configurable text rotation and timing
- CSS-based cursor animation

## Development Workflow

1. **Adding New Pages**:
   - Copy template from existing page
   - Maintain navbar and footer structure
   - Update meta tags and title

2. **Styling Changes**:
   - Add custom styles to `custom.css`
   - Use Bootstrap classes when possible
   - Override Bootstrap in `custom.css` as needed

3. **Adding Portfolio Items**:
   ```html
   <div class="col-12 col-md-4">
       <div class="card">
           <img class="portfolio-img" 
                data-type="image|video"
                data-src="source-url"
                data-title="Item Title"
                data-desc="Description">
           <!-- Card body... -->
       </div>
   </div>
   ```

## Common Tasks

1. **Update Content**:
   - Edit HTML files directly
   - Maintain semantic structure with header/main/aside
   - Keep Bootstrap grid system intact

2. **Add New Sections**:
   - Use Bootstrap card components
   - Follow responsive grid patterns
   - Maintain consistent spacing

3. **Modify Styles**:
   - Check `custom.css` for existing overrides
   - Use Bootstrap utilities when possible
   - Follow media query structure for responsive changes

## Important Notes

- Always maintain responsive behavior
- Test dark/light mode when making changes
- Keep JavaScript modular and unobtrusive
- Preserve accessibility features (ARIA labels, semantic HTML)
- Use provided Google Fonts: Oswald for headings, Montserrat for body text